﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.IO;

namespace list
{


    public class Job
    {
        public Guid Id { get; set; }
        public string Company { get; set; }
        public bool HaveApplied { get; set; }
        public string Position { get; set; }
        public Category Category { get; set; } //it used to enum
        public DateTime DueDate { get; set; }
        public DateTime AppliedDate { get; set; }
        public string ContactPersonFirstName { get; set; }
        public string ContactPersonLastName { get; set; }
        public string Link { get; set; }
        // private [LogEntry] history;
      
        public override string ToString()
        {
            return string.Format("[Job: Id={0}, Company={1}, HaveApplied={2}, Position={3}, Category={4}, DueDate={5}, AppliedDate={6}, ContactPersonFirstName={7}, ContactPersonLastName={8}, Link={9}]", Id, Company, HaveApplied, Position, Category, DueDate, AppliedDate, ContactPersonFirstName, ContactPersonLastName, Link);
        }
    }

    public enum Category
    {
        Developer,
        Designer
    }

    class MainClass
    {
        private static void Main(string[] args)
        { 
            XmlWriterSettings ws = new XmlWriterSettings();
            ws.Indent = true;

            List<Job> jobList = new List<Job>();
            Job newJob = new Job();



        using (XmlReader reader = XmlReader.Create("jobsDB.xml"))
            {
                Job currentJob = null;

                while (reader.Read())
                {
                    string field = null;

                    switch (reader.NodeType)
                    {
                        case XmlNodeType.Element:
                            string elName = reader.Name;
                            switch (elName)
                            {
                                case "Job":
                                    {
                                        currentJob = new Job();
                                        break;
                                    }
                                case "GUID":
                                    {
                                        field = "GUID";
                                        break;
                                    }
                                case "Company":
                                    {
                                        field = "Company";
                                        break;
                                    }
                                case "Position":
                                    {
                                        field = "Position";
                                        break;
                                    }
                                case "Category":
                                    {
                                        field = "Category";
                                        break;
                                    }
                                case "HaveApplied":
                                    {
                                        field = "HaveApplied";
                                        break;
                                    }
                                case "DueDate":
                                    {
                                        field = "DueDate";
                                        break;
                                    }
                                case "AppliedDate":
                                    {
                                        field = "AppliedDate";
                                        break;
                                    }
                                case "ContactPersonFirstName":
                                    {
                                        field = "ContactPersonFirstName";
                                        break;
                                    }
                                case "ContactPersonLastName":
                                    {
                                        field = "ContactPersonLastName";
                                        break;
                                    }
                                case "Link":
                                    {
                                        field = "Link";
                                        break;
                                    }
                            }
                            break;
                        case XmlNodeType.Text:
                            string elValue = reader.Value;
                            switch (field)
                            {
                                case "Job":
                                    break;
                                case "GUID":
                                    {
                                        currentJob.Id = Guid.Parse(elValue);
                                        break;
                                    }
                                case "Company":
                                    {
                                        currentJob.Company = elValue;
                                        break;
                                    }
                                case "Position":
                                    {
                                        currentJob.Position = elValue;
                                        break;
                                    }
                                case "Category":
                                    {
                                        currentJob.Category = (Category)Enum.Parse(typeof(Category), elValue);
                                        break;
                                    }
                                case "HaveApplied":
                                    {
                                        currentJob.HaveApplied = bool.Parse(elValue);
                                        break;
                                    }
                                case "DueDate":
                                    {
                                        currentJob.DueDate = DateTime.Parse(elValue);
                                        break;
                                    }
                                case "AppliedDate":
                                    {
                                        currentJob.AppliedDate = DateTime.Parse(elValue);
                                        break;
                                    }
                                case "ContactPersonFirstName":
                                    {
                                        currentJob.ContactPersonFirstName = elValue;
                                        break;
                                    }
                                case "ContactPersonLastName":
                                    {
                                        currentJob.ContactPersonLastName = elValue;
                                        break;
                                    }
                                case "Link":
                                    {
                                        currentJob.Link = elValue;
                                        break;
                                    }
                            }

                            break;
                        case XmlNodeType.XmlDeclaration:
                        // <? xml ?>
                        case XmlNodeType.ProcessingInstruction:
                            break;
                        case XmlNodeType.EndElement:
                            if (reader.Value == "Job")
                                jobList.Add(currentJob);
                            break;
                    }
                }
            }
            jobList.ForEach(Console.WriteLine);

            Console.WriteLine("Enter Jobs That you want to apply\n");
            while ((Console.ReadLine()!="quit"))
            {
                Console.WriteLine("Enter Jobs That you want to apply\n");
                //To added the user in alist.
                //string userInput for to do list the use wanting.
                string userInput;
                //Get console from the user and put it to userInput
                userInput = Console.ReadLine();
                jobList.Add(addToTheList(newJob, userInput));
                //Added the list of input
                int size = jobList.Count();
                Console.WriteLine(size);
                jobList.ForEach(Console.WriteLine);
            }

            using (XmlWriter writer = XmlWriter.Create("jobsDB.xml", ws))
            {
                writer.WriteStartElement("Jobs");
                foreach (Job job in jobList)
                {
                    writer.WriteStartElement("Job");
                    writer.WriteElementString("GUID", job.Id.ToString());
                    writer.WriteElementString("Company", job.Company);
                    writer.WriteElementString("Position", job.Position);
                    writer.WriteElementString("Category", job.Category.ToString());
                    writer.WriteElementString("HaveApplied", job.HaveApplied.ToString());
                    writer.WriteElementString("DueDate", job.DueDate.ToShortDateString());
                    writer.WriteElementString("AppliedDate", job.AppliedDate.ToShortDateString());
                    writer.WriteElementString("ContactPersonFirstName", job.ContactPersonFirstName);
                    writer.WriteElementString("ContactPersonLastName", job.ContactPersonLastName);
                    writer.WriteElementString("Link", job.Link);
                    writer.WriteEndElement();

                }
                writer.WriteEndElement();
                writer.Flush();
            }
        }
        //To add to list from the textbox.
        public static Job addToTheList (Job newjob, string userinput){
            //split the all of them.
            string[] tokens = userinput.Split(' ');
            Console.WriteLine();
            newjob.Id = Guid.NewGuid();
            newjob.Company = tokens[0];
            newjob.Category = (Category)Enum.Parse(typeof(Category), tokens[2]);
            newjob.Position = tokens[1];
            newjob.AppliedDate = DateTime.Today;
            newjob.DueDate = DateTime.Today;
            newjob.ContactPersonFirstName = tokens[3];
            newjob.ContactPersonLastName =tokens[4];
            newjob.Link = tokens[5];
            // jobList.Add(newjob); 
            return newjob;
        }
        // To delete the specific one from the list.
        public static void deleteJob(List<Job> list,string userinput)
        {
            //change using input after the user
            var itemToRemove = list.Single(r => r.Company == userinput);
            list.Remove(itemToRemove);
            Console.WriteLine("Job is deleted from the TO-DO list\n");
        }


     }
}
